package net.sf.jml;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;

import net.sf.jml.exception.JmlException;
import net.sf.jml.util.DigestUtils;
import net.sf.jml.util.StringUtils;

public final class MsnObject {

    public static final int TYPE_CUSTOM_EMOTICON = 2;
    public static final int TYPE_DISPLAY_PICTURE = 3;
    public static final int TYPE_BACKGROUND = 5;
    public static final int TYPE_DYNAMIC_DISPLAY_PICTURE = 7;
    public static final int TYPE_WINKS = 8;
    public static final int TYPE_VOICE_CLIP = 11;
    public static final int TYPE_ADDIN_SAVED_STATE = 12;
    public static final int TYPE_MSNP15_LOCATION = 14;

    private String creator;
    private int type = TYPE_DISPLAY_PICTURE;
    private String location = "joy.tmp";
    private String friendly = "AAA=";
    private String sha1d;
    private String sha1c;
    private byte msnObj[];

    public static MsnObject getInstance(String creator, byte picture[]) throws JmlException{
        if (creator == null)throw new JmlException(
                "Creator can't null!");
        if (picture == null)throw new JmlException(
                "Picture can't null!");
        return new MsnObject(creator,picture);
    }

    public static MsnObject getInstance(String creator, String pictureFileName) throws JmlException {
        byte[] pic;
        try {
            RandomAccessFile msnObjFile = new RandomAccessFile(pictureFileName,
                    "r");
            pic = new byte[(int) msnObjFile.length()];
            msnObjFile.readFully(pic);
            msnObjFile.close();
        } catch (FileNotFoundException ex) {
            throw new JmlException(
                    "File " + pictureFileName + " not found!",ex);
        } catch (IOException ex) {
            throw new JmlException(
                    "File " + pictureFileName + " can't access!",ex);
        }
        return getInstance(creator,pic);
    }

    private MsnObject(String creator, byte msnObj[]) {
        this.creator = creator;
        this.msnObj = msnObj;
        generate();
    }

    private void generate() {
        sha1d = StringUtils.encodeBase64(DigestUtils.sha1(msnObj));
        String tmpSha1c = "Creator" + getCreator() + "Size" + msnObj.length +
                          "Type" + this.getType() + "Location" + getLocation() +
                          "Friendly" +
                          this.getFriendly() + "SHA1D" + sha1d;
        sha1c = StringUtils.encodeBase64(DigestUtils.sha1(tmpSha1c.getBytes()));
    }

    public String getCreator() {
        return creator;
    }


    public void setCreator(String creator) {
        this.creator = creator;
        generate();
    }


    public int getSize() {
        return msnObj.length;
    }


    public int getType() {
        return type;
    }


    public void setType(int type) {
        this.type = type;
        generate();
    }


    public String getLocation() {
        return location;
    }


    public void setLocation(String location) {
        this.location = location;
        generate();
    }


    public String getFriendly() {
        return friendly;
    }


    public void setFriendly(String friendly) {
        if (friendly == null) return;
        try {
            friendly = StringUtils.encodeBase64(friendly.getBytes("UTF-16BE"));
        } catch (UnsupportedEncodingException ex) {
            friendly = StringUtils.encodeBase64(friendly.getBytes());
        }
        this.friendly = friendly;
        generate();
    }

    public String getSha1d() {
        return sha1d;
    }


    public String getSha1c() {
        return sha1c;
    }

    public byte[] getMsnObj() {
        return msnObj;
    }


    @Override
	public String toString() {
        StringBuffer ret = new StringBuffer("<msnobj Creator=");
        ret.append("\"").append(this.getCreator()).append("\"");
        ret.append(" Size=");
        ret.append("\"").append(this.getSize()).append("\"");
        ret.append(" Type=");
        ret.append("\"").append(this.getType()).append("\"");
        ret.append(" Location=");
        ret.append("\"").append(this.getLocation()).append("\"");
        ret.append(" Friendly=");
        ret.append("\"").append(this.getFriendly()).append("\"");
        ret.append(" SHA1D=");
        ret.append("\"").append(this.getSha1d()).append("\"");
        ret.append(" SHA1C=");
        ret.append("\"").append(this.getSha1c()).append("\"");
        ret.append("/>");
        return ret.toString();
    }

    @Override
	public boolean equals(Object object) {
        if (getSha1c() == null) return false;

        if (this == object) {
            return true;
        }

        if (object == null || !(object instanceof MsnObject)) {
        	return false;
        }
        		
        return getSha1c().equals(((MsnObject) object).getSha1c());
    }
}
