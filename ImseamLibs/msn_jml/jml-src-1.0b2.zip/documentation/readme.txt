JML (http://sourceforge.net/projects/java-jml/)
================================================

1.Requirements
	- JDK 1.5 or higher.
		http://java.sun.com/j2se/1.5.0/	
	- Cindy
		http://cindy.sourceforge.net/
	- Apache Commons-Logging
		http://jakarta.apache.org/commons/logging/

2.Running JML Example
	Make sure you have all required jars in your classpath.
    --> java net.sf.jml.example.SimpleMsn email password
   
3.Thanks
	Mike Mintz & Andrew Sayers
		http://www.hypothetic.org/docs/msn/index.php  
	ZoRoNaX
		http://siebe.bot2k3.net/docs
	Siebe Tolsma	
		http://zoronax.bot2k3.net
    George Joseph		
	Richard Thibault

4.Known Issues
	- do not support file transfer
